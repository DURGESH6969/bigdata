import pandas as pd
df=pd.read_csv("Book1.csv")
print("The student data is: ")
print(df)
print("First 3 rows are: ")
print(df.head(3))
print("Last 3 rows of first column are: ")
print(df.iloc[-3:,0])