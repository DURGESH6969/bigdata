import matplotlib.pyplot as pt
import pandas as pd
data=pd.read_csv("as20.csv")
list1=[]
for i in data:
    list1.append(i)
print(list1)
barchart=pt.bar(x=list1[0],y=list1[2],color='green') 
pt.show()   