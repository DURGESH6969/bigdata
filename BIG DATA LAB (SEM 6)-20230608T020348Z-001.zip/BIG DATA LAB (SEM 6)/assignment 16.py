import pandas as pd
data=pd.read_csv("as16.csv")
print(data)
print(data.columns)
newRow={}
name=input("Enter the name: ")
year=input("Enter the year of the student: ")
roll=input("Enter the roll no of the student: ")
newRow['NAME']=name
newRow['YEAR']=year
newRow['ROLL NO']=roll
print(newRow)
data=data.append(newRow,ignore_index=True)
data.to_csv("as16.csv",index=False)
data=pd.read_csv("as16.csv")
print(data)