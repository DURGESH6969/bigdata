import numpy as np
matrix=[]
for i in range(3):
    for j in range(3):
        matrix.append(int(input("Enter the values: ")))
print(matrix)
arr=np.array(matrix).reshape(3,3)
print(arr)
new_row=np.array([1,2,3])
arr=np.vstack((arr,new_row))
print("Array after adding row: ")
print(arr)
new_col=np.array([1,2,3,4])
arr=np.column_stack((arr,new_col))
print("Array after adding column and row: ")
print(arr)        