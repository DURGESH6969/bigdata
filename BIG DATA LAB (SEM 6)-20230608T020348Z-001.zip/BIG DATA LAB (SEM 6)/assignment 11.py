import pandas as pd
n=int(input("Enter the number of elements: "))
list1=[]
list2=[]
print("Enter the elements of first list: ")
for i in range(n):
    list1.append(int(input()))
print("Enter the elements of second list: ")
for i in range(n):
    list2.append(int(input()))
series1=pd.Series(list1)
series2=pd.Series(list2)
print("Addition: ")
print(series1+series2)
print("Subtraction: ") 
print(series1-series2)
print("Multiplication: ")
print(series1*series2)
print("Division: ")
print(series1/series2)    