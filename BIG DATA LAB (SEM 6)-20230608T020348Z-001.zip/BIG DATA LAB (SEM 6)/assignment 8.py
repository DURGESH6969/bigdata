import numpy as np
iden=np.identity(4)
print(iden)
mat1=[]
mat2=[]
for i in range(2):
    for j in range(2):
        mat1.append(int(input("Enter the value: ")))
matrix1=np.reshape(mat1,(2,2))
print("Matrix 1: ")
print(matrix1)
for i in range(2):
    for j in range(2):
        mat2.append(int(input("Enter the value: "))) 
matrix2=np.reshape(mat2,(2,2))
print("Matrix 2: ")
print(matrix2)
result=np.add(matrix1,matrix2)
print("Addition result: ")
print(result)
t=matrix1.transpose()
print("Transpose of matrix 1: ")
print(t)
n=np.dot(t,matrix2)
print("Multiplication result: ")
print(n)