num=int(input("Enter a number: "))
fact=1
if num<0:
    print("Factorial of negative numbers do not exist.")
elif(num==0 or num==1):
    print("Factorial is: ",num)
else:
    for i in range(1,num+1):
        fact=fact*i 
    print("Factorial is: ",fact)           