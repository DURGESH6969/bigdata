str=input("Enter a string: ")
cpy=" "
for i in range(len(str)-1,-1,-1):
    cpy+=str[i]
if(str==cpy):
    print(str,"is a palindrome!")
else:
    print(str,"is not a palindrome!")        