str=input("Enter a string: ")
strlen=len(str)
vCount=0
cCount=0
vowel=['a','e','i','o','u','A','E','I','O','U']
for i in range(0,strlen):
    if(str[i].isalpha()):
        if(str[i] in vowel):
            vCount=vCount+1
        else:
            cCount=cCount+1
print("Vowel Count: ",vCount)
print("Consonant Count: ",cCount)                