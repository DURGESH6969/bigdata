import pandas as pd
dictioanry={}
n=int(input("Enter the number of keys: "))
for i in range (n):
    temp=[]
    m=int(input("Enter the number of elements in value list %s: "%(i+1)))
    print("Enter the values: ")
    for j in range (m):
        temp.append(int(input()))
    dictioanry[i]=temp
print("Original dictionary: ")
print(dictioanry)
series=pd.Series(dictioanry)
print("Panda series: ")
print(series)        