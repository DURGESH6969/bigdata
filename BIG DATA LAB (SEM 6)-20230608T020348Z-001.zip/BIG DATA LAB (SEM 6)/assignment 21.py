import matplotlib.pyplot as pt
import pandas as pd
data=pd.read_csv("as21.csv")
print(data)
list1=list(data.columns)
print(list1)
piechart=data.groupby(list[1])(list1[3]).mean()
piechart.plot(kind="pie",autopct="%1.0F % %")