import pandas as pd
employee=[]
n=int(input("Insert number of records: "))
for i in range(n):
    values=input("Enter values: ")
    list=values.split(",")
    tuple1=tuple(list)
    employee.append(tuple1)
print(employee)
df=pd.DataFrame(employee,columns=['Name','Class','Roll No.'])
df.to_csv("Anurag.csv",index=False)    