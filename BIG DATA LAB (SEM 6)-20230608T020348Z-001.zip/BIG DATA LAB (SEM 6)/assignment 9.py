import numpy as np
matrix=[[4,2,3],[4,6,6],[7,1,97]]
a=np.array(matrix)
print("after sorting in 1d array: ")
print(np.sort(a,axis=None))
print("Column wise: ",np.sort(a,axis=0))
print("Row wise: ",np.sort(a,axis=1))