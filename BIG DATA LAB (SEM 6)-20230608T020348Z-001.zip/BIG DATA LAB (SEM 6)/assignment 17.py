import matplotlib.pyplot as pt
x=[]
y=[]
n=int(input("Enter the number of points: "))
for i in range(n):
    x.append(int(input("Enter the point in x axis: ")))
    y.append(int(input("Enter the point in y axis: ")))
pt.plot(x,y,'.g')
pt.xlabel('x-axis')
pt.ylabel('y=axis')
pt.title("Assignment 17")
pt.show()    