n=int(input("Enter the number of months: "))
month=[]
mon=[]
for i in range(0,n):
    month.append(input("Enter the month name: "))
for i in month:
    mon.append(i[0:3].upper())
print("Original list is: ",month) 
print("Shortname list is: ",mon)       