import matplotlib.pyplot as pt
import numpy as np
x=np.linspace(-np.pi,np.pi,100)
y=np.sin(x)
pt.plot(x,y,'_b')
pt.show()