import matplotlib.pyplot as pt
import numpy as np
x=np.linspace(-5,10,6)
s=int(input("Enter the slope: "))
c=int(input("Enter the constant: "))
y=s*x+c
pt.plot(x,y,'.g')
pt.title("Assignment-18")
pt.show()