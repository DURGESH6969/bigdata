count={}
original=[]
n=int(input("Enter the number of elements: "))
for i in range(0,n):
    original.append(int(input("Enter the element: ")))
for i in original:
    if(i not in count):
        count[i]=1
    else:
        count[i]=count[i]+1
print("Count: ",count)                