n=int(input("Enter the size of the list: "))
list=[]
for i in range(0,n):
    list.append(int(input("Enter the element: ")))
print("Original list is: ",list)
list.reverse()
print("Reverse list is: ",list)
list.sort()
print("Sorted in ascending order: ",list)
list.sort(reverse=True)
print("Sorted in descending order: ",list)    