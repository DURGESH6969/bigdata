import numpy as np
m=int(input("Enter the number of rows: "))
n=int(input("Enter the number of columns: "))
matrix=[]
for i in range(0,m):
    temp=[]
    for j in range(0,n):
        temp.append(int(input("Enter the element: ")))
    matrix.append(temp)
print(np.array(matrix))
print("Minimum number is: ",end=" ")
print(np.min(matrix))
print("Maximum number is: ",end=" ")
print(np.max(matrix))
rowsort=np.sort(matrix,axis=1)
print("Row wise sorted: ",rowsort) 
colsort=np.sort(matrix,axis=0)
print("Column wise sorted: ",colsort)       