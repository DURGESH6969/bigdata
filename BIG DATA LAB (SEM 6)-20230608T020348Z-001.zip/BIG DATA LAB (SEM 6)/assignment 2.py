n=int(input("Enter the size of the list: "))
num=[]
odd=[]
even=[]
for i in range(0,n):
    num.append(int(input("Enter the element: ")))
for i in num:
    if(i%2==0):
        even.append(i)
    else:
        odd.append(i)
print("Original list is: ",num)
print("Even list is: ",even)
print("Odd list is: ",odd)                